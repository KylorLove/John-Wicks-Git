print("Don't fear!")
print("I'm here!")

