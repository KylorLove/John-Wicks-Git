### Module 5 Prep Assignment 2
### Kylor Love 2412119
### define main
  # set temp variable to gather input
  # call convert(temp) function
  # display temp
  # define convert(temp) function
  # set cel_fah variable = to input c/f
  # use if statement to decifer input to convert celsius to fahrenheit or opposite
  # display converted temperature
  # call main() function

# define main function

def main():
    temp = float(input('Enter a temperature:'))
    convert(temp)
    print(temp)
    
# define convert(temp) function   

def convert(temp):
    cel_fah = input('Was that input Fahrenheit or Celsius c/f?:')
# if statements

    if cel_fah == 'f':
        temp = (temp - 30)/2
    else:
        if cel_fah == 'c':
            temp = (temp * 1.8) + 32
# display output
    
    print('The conversion is', temp,'is greater than')

# call main function
    
main()
