### Module 5 Prep Assignment
### Kylor Love 2412119
### def main()
  # set variable for input named integer
  # create second function show_larger
  # define second function = to integer
  # set second input variable named number
  # set parameter number >= integer
  # set variable to determine difference = number - integer
  # display output
  # call main() function

# define main
def main():
# input variable
    integer = int(input('Type a number:'))
    show_larger(integer)
    
# define show_larger
def show_larger(integer):
    number = int(input('Type a number:'))
    number >= integer
    difference = number - integer
# display output
    print(number,'is greater than (or equal to if by 0)',integer,'by',difference)
#call main
main()
    
