# program2_3.py
# Kylor Love 2412119
# Prompt user for a numerator and a denominator.
# Put the two numbers into the fraction using a variable named fraction.
# Compute the fration to produce a mixed number.

def main():
    # prompt user for input
    num = int(input('Enter Numerator:'))

    den = float(input('Enter denominator:'))

    fraction = num / den

    print(fraction)

# Collaborators: none.

main()

            
              
    
    
