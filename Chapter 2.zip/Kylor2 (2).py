# program2_1.py
# Kylor Love 2412119
# Get user to enter their first name, then get them to enter their last name
# and age. Produce a sentence using the inputs from the user. 


def main():

   first_name = input('Enter first name:')
   last_name = input('Enter last name:')
   years_old = input('Enter age:')

   name1 = first_name

   name2 = last_name

   age = years_old

   print('Hello my name is',name1,name2,'and I am',age,'years old')

# Collaborators: none.


main()
