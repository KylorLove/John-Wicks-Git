# program2_3.py
# Kylor Love 2412119
# Prompt the user for a input named radius.
# Compute the radius provided by the user by multiplying it times pie.
# Give area.

def main():
    # prompt user for input
    pie = 3.1416

    radius = int(input('Enter radius:'))

    area = pie * radius

    print(area)

# Collaborators: none.

main()
    
