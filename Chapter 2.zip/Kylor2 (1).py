# program2_2.py
# Kylor Love 2412119
# Get user to input a quantity and a price.
# Compute the quantity and price using multiplication to get a product.
# Produce a short sentence including the price as the total.

def main():
    # prompt user for quanity
    qty = int(input('Enter quanity:'))

    price = float(input('Enter price:'))

    total = qty * price

    print('The total is $',total)

# Collaborators: none.

main()
    
