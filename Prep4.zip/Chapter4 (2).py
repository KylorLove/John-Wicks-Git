# Chapter4_Prep2
# Kylor Love 2412119

# start with def main():
# create a variable named number and set it = to 0
# create a while loop while True:
# prompt for user input in form of an integer
# set user input equal to a variable named entry
# write in a sentinel if entry == 0
# display all done when finished by using print function
# end with main()

def main():
    # number variable
    number = 0
    # while loop
    while True:
    # entry variable prompting for user input
        entry = int(input('Enter a integer or 0 to quit'))
    # sentinel to end loop when user enters a 0
        if entry == 0:
    # display all done whn finished       
            print('All done!')
            break
    #end with main()
        
        
        

            
        
     
    
                     
        
       
main()
